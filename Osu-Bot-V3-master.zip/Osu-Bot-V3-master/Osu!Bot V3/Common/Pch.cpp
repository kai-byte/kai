// Pch.cpp : Source file that includes just the standard includes
// $safeprojectname$.pch will be the pre-compiled header
// Pch.obj will contain the pre-compiled type information

#include <Common/Pch.h>