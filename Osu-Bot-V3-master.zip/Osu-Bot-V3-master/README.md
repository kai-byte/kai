# Osu!Bot V3
Version 3 of my cursor dancing bot that can, play the Rhythm game called Osu! (standard mode).

USE THIS WITH RESPONSABLITY!!
I DO NOT, I REPEAT, I DO NOT TAKE RESPONSABILITY IF YOU GET YOUR ACCOUNT BANNED/RESTRICTED ON OSU!

**PROTIP: It is safer to logout of your account before letting Osu!Bot play any beatmap.**

## Video Showcase Playlist
*COMING SOON*

## Downloadable Executables
[Latest release](https://github.com/DDDinggo22/Osu-Bot-V3/releases/tag/v190205 "Goto latest release")  
[Releases](https://github.com/DDDinggo22/Osu-Bot-V3/releases "All releases")

## Usage Instructions
0. Unzip anywhere you like.
1. Execute (Osu!Bot V3).
   - Osu!Bot V3_x64.exe on 64-bit windows systems
   - Osu!Bot V3_x86.exe on 32-bit windows systems
2. Press \***insert**\* to queue a beatmap.
3. Play any of the queued maps.
4. Relax and see Osu!Bot V3 dance over the playing field.

### Hotkey layout
* \***Home**\* toggles the HUD
* \***TAB**\* toggles Debug UI elements
	 - Current time / "signature not found" message
	 - Current updates per second the bot is running at
* \***Insert**\* Allows the user to add beatmaps to the queue

## Remarks
### Known issues
* Sometimes the beatmap does not get added to the queue.  
   I am investigating the problem, but it does not seem to affect other features of the bot.
* Hotkeys are system wide, meaning they will activate from anywhere.  
   This will soon change to a localized key input.

### Compatibility
* Osu!Bot V3 is **NOT** yet able to play with the "**Hardrock**" mod.  
	 But works fine with all other mods.
* Osu!Bot V3 does **NOT** have the ability to select the beatmap automaticly, like V2 could.  
   I am still working on this.
* Osu!Bot V3 has a HUD that works **ONLY** when osu is in **borderless** or **windowed** mode.  
   Making it work in fullscreen mode is extremly difficult. And will not be a priority feature.
* Osu!Bot V3 is using "**mouse button 1**" as its form of clicking.  
   Soon this will be customizable to keyboard too.
* For now dance modes are hard coded.  
   But they will be back very soon.
	 
### Features
* Any new feature request can be made on my discord server [here](discord.me/Disguard "Join Disguard").
